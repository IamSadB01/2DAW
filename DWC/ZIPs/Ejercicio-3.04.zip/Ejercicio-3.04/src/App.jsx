import React from 'react';
import './App.css';
import ContenedorPeliculas from './componentes/ContenedorPeliculas.jsx';

function App() {
  return (
    <React.Fragment>
      <ContenedorPeliculas />
    </React.Fragment>
  );
}

export default App