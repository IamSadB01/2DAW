import React, { Fragment } from 'react';
import Contenedor from './componentes/ej1/Contenedor.jsx';
import ApuestaEuromillon from './componentes/ej2/ApuestaEuromillon.jsx';

const App = () => {
  return (
    <Fragment> 
      <Contenedor /> {/* Ejercicio 1 */}
      {/* <ApuestaEuromillon /> */} {/* Ejercicio 2 */}
    </Fragment>
  );
};

export default App;