import React from 'react';
import Rutas from  '../Rutas.jsx';

const Contenedor = () => {
  return (
    <Rutas />
  )
}

export default Contenedor