import React from 'react';
import '../css/Cabecera.css';

const Cabecera = () => {
  return (
    <div className='Cabecera'>
        <h1>Práctica 3.06</h1>
        <p>Designed by: Sergio Alfonso Deltell</p>
    </div>
  )
}

export default Cabecera