import React from 'react'

const PorTituloPage = () => {
  return (
    <div className='PorTituloPage'>PorTituloPage</div>
  )
}

export default PorTituloPage