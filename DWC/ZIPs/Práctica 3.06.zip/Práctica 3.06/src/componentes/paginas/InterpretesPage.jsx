import React from 'react';
import './InterpretesPage.css';

const InterpretesPage = () => {
  return (
    <div className="InterpretesPage-container">
      <div className='InterpretesPage'>
        <h1>Intérpretes</h1>
        <p>Información sobre los actores y actrices de las películas.</p>
      </div>
    </div>
  )
}

export default InterpretesPage;