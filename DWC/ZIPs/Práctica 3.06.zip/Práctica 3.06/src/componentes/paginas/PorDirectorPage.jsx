import React from 'react'

const PorDirectorPage = () => {
  return (
    <div className='PorDirectorPage'>PorDirectorPage</div>
  )
}

export default PorDirectorPage