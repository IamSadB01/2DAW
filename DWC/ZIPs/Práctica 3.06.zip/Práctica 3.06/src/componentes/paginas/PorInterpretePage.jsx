import React from 'react'

const PorInterpretePage = () => {
  return (
    <div className='PorInterpretePage'>PorInterpretePage</div>
  )
}

export default PorInterpretePage