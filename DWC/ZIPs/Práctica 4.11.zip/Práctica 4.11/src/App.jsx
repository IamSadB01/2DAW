import { Fragment } from 'react';
import ListaCompra from './componentes/ListaCompra.jsx';
import './style.css';

const App = () => {
  return (
    <Fragment>
      <ListaCompra />
    </Fragment>
  );
};

export default App;
