import React, { Fragment } from "react";
import EnciclopediaPage from "./componentes/EnciclopediaPage.jsx";
import "./App.css";

const App = () => {
  return (
    <Fragment>
      <EnciclopediaPage />
    </Fragment>
  );
};

export default App;
